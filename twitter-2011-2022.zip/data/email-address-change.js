window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "340580811",
      "emailChange" : {
        "changedAt" : "2011-07-22T22:56:49.000Z",
        "changedTo" : "radmon@stan4d.net"
      }
    }
  },
  {
    "emailAddressChange" : {
      "accountId" : "340580811",
      "emailChange" : {
        "changedAt" : "2018-12-22T21:24:34.000Z",
        "changedFrom" : "radmon@stan4d.net",
        "changedTo" : "jjs@sdf.org"
      }
    }
  },
  {
    "emailAddressChange" : {
      "accountId" : "340580811",
      "emailChange" : {
        "changedAt" : "2022-08-20T16:30:22.000Z",
        "changedFrom" : "jjs@sdf.org",
        "changedTo" : ""
      }
    }
  },
  {
    "emailAddressChange" : {
      "accountId" : "340580811",
      "emailChange" : {
        "changedAt" : "2022-08-20T16:30:22.000Z",
        "changedFrom" : "",
        "changedTo" : "jjs@tilde.team"
      }
    }
  }
]