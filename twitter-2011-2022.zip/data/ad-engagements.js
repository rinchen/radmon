window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 20:03:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 20:03:31",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 20:30:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 20:31:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 20:36:37"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 20:36:45",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1569710879813369858",
                  "tweetText" : "Succession and more Emmy® winners are now streaming on HBO Max.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "HBO Max",
                  "screenName" : "@hbomax"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "HBO Max - All Site Traffic"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "HBO Max Account Created"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "HBO Max Subscription Start (No Free Trial)"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install HBO Max: Stream TV & Movies ANDROID All"
                  },
                  {
                    "targetingType" : "Website Activity"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install HBO Max: Stream TV & Movies IOS All"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "HMX_Retail_Wholesale_Suppression (email)"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "HMX_Retail_Wholesale_Suppression (Device Id)"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  }
                ],
                "impressionTime" : "2022-09-24 20:07:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 20:07:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "90933",
                  "name" : "#SuperNaturalSeries",
                  "description" : "Now Streaming on Disney+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-09-24 20:34:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-09-24 20:34:35",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92280",
                  "name" : "#Disenchanted",
                  "description" : "Original movie now streaming"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-11-20 16:49:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-20 16:49:53",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92280",
                  "name" : "#Disenchanted",
                  "description" : "Original movie now streaming"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@DisneyPlus"
                },
                "impressionTime" : "2022-11-20 16:41:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-20 16:41:10",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1588163082752180224",
                  "tweetText" : "Check out your love &amp; relationship forecast  💖🔞",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Astrology Daily",
                  "screenName" : "@YourAstrologyD"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States of America"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  }
                ],
                "impressionTime" : "2022-11-20 16:41:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-20 16:41:54",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  }
]