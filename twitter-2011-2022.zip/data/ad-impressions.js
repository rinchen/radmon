window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:30:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:03:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:36:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1569710879813369858",
                "tweetText" : "Succession and more Emmy® winners are now streaming on HBO Max.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "HBO Max",
                "screenName" : "@hbomax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "HBO Max - All Site Traffic"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "HBO Max Account Created"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "HBO Max Subscription Start (No Free Trial)"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install HBO Max: Stream TV & Movies ANDROID All"
                },
                {
                  "targetingType" : "Website Activity"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install HBO Max: Stream TV & Movies IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "HMX_Retail_Wholesale_Suppression (email)"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "HMX_Retail_Wholesale_Suppression (Device Id)"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2022-09-24 20:07:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Fight For 15",
                "screenName" : "@fightfor15"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:30:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:36:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:32:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:03:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:34:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "SEIU",
                "screenName" : "@SEIU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-09-24 20:34:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGM 🦁",
                "screenName" : "@BetMGM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "List",
                  "targetingValue" : "Global - Self Excluded - Final - CDP_1663751121400"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "BetMGM - Existing Customer - All States_1661945234116"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Colorado"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2022-09-24 20:07:03"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Prime Video",
                "screenName" : "@PrimeVideo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-11-20 16:40:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1588163082752180224",
                "tweetText" : "Check out your love &amp; relationship forecast  💖🔞",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Astrology Daily",
                "screenName" : "@YourAstrologyD"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-11-20 16:41:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Yes for Parks & Homes",
                "screenName" : "@parksandhomes"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Denver CO, US"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-11-20 16:41:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Yes for Parks & Homes",
                "screenName" : "@parksandhomes"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Denver CO, US"
                }
              ],
              "impressionTime" : "2022-11-20 16:41:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Yes for Parks & Homes",
                "screenName" : "@parksandhomes"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Denver CO, US"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-11-20 16:49:47"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "DuckDuckGo",
                "screenName" : "@DuckDuckGo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-11-21 18:09:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "DuckDuckGo",
                "screenName" : "@DuckDuckGo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States of America"
                }
              ],
              "impressionTime" : "2022-11-21 18:10:48"
            }
          ]
        }
      }
    }
  }
]