window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "Arduino Radiation Monitor",
      "description" : "Arduino Radiation Monitor",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2021-02-15T14:49:14.000Z",
      "id" : "1114425"
    }
  }
]