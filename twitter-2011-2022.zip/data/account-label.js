window.YTD.account_label.part0 = [
  {
    "accountLabel" : { }
  }
]