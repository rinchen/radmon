window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "deviceType" : "Auth",
        "carrier" : "t_mobile_us",
        "phoneNumber" : "+13038874755",
        "createdDate" : "2018.12.22"
      }
    }
  }
]