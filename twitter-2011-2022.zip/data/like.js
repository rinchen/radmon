window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1548274150954844165",
      "fullText" : "1.2667 uSv/h (slightly elevated)",
      "expandedUrl" : "https://twitter.com/i/web/status/1548274150954844165"
    }
  },
  {
    "like" : {
      "tweetId" : "1548390184894402560",
      "fullText" : "@LongmontRadMon First slightly elevated I've seen. Visual horrors",
      "expandedUrl" : "https://twitter.com/i/web/status/1548390184894402560"
    }
  },
  {
    "like" : {
      "tweetId" : "201420516211441664",
      "fullText" : "BOULDER: Fukishima Fallout http://t.co/FM25PAv8",
      "expandedUrl" : "https://twitter.com/i/web/status/201420516211441664"
    }
  }
]