window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Volunteer radiation monitor located in NE Longmont, Colorado, USA. See website below for more details.",
        "website" : "http://t.co/8oGZBfrJSV",
        "location" : "Longmont, Colorado, USA"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/2213177300/toxic_radiation_logo_avatar_picture_86004_reasonably_small.gif",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/340580811/1545514134"
    }
  }
]