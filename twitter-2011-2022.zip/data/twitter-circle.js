window.YTD.twitter_circle.part0 = [
  {
    "twitterCircle" : {
      "id" : "1594370553032626176",
      "ownerUserId" : "340580811",
      "createdAt" : "2022-11-20T16:42:16.472Z"
    }
  }
]