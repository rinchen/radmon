window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "340580811",
      "timeZone" : "Central Time (US & Canada)"
    }
  }
]