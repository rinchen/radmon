window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "jjs@tilde.team",
      "createdVia" : "web",
      "username" : "LongmontRadMon",
      "accountId" : "340580811",
      "createdAt" : "2011-07-22T22:55:59.000Z",
      "accountDisplayName" : "Radiation Monitor"
    }
  }
]