window.YTD.phone_number.part0 = [
  {
    "device" : {
      "phoneNumber" : "+13038874755"
    }
  }
]