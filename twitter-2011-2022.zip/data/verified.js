window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "340580811",
      "verified" : false
    }
  }
]