window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "BRo6kiIjUybhBNdLrdgJxrR3b55FvYpQMmxEfgnJ",
      "createdAt" : "2022-08-20T16:27:49.352Z",
      "lastSeenAt" : "2022-08-20T16:27:49.354Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "uSL7LSKObabImF1kQvHejIqRPAvzLYtLOMRW14d6",
      "createdAt" : "2022-11-21T18:09:15.081Z",
      "lastSeenAt" : "2022-11-21T18:09:15.083Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]