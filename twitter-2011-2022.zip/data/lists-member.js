window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RockyMtnDavid/lists/radiation-18764"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Rubonist/lists/nuclear-in-nature"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/dissensusjapan/lists/radiation-monitorings"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/daystech/lists/work"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/getsusanmktg/lists/longmont-co-folks"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bearishtrader/lists/nuclear-and-radiological"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Risu_Squirrel/lists/emergency"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gaz2002/lists/goodfolks-blokes"
    }
  }
]